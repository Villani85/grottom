"use client"

import { useState, useEffect, useRef } from "react"
import { AdminRequired } from "@/components/AdminRequired"
import { DemoModeBanner } from "@/components/DemoModeBanner"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getFirebaseIdToken } from "@/lib/api-helpers"
import { useAuth } from "@/context/AuthContext"
import { loadBroadcastSdk, createBroadcastClient } from "@/lib/ivs/loadBroadcastSdk"

export default function AdminLivePage() {
  const { user, isLoading: authLoading } = useAuth()
  const [status, setStatus] = useState<string>("Inizializzazione...")
  const [isBroadcasting, setIsBroadcasting] = useState(false)
  const [isScreenSharing, setIsScreenSharing] = useState(false)
  const [sdkReady, setSdkReady] = useState(false)
  const [configReady, setConfigReady] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [recordings, setRecordings] = useState<any[]>([])
  const [recordingsLoading, setRecordingsLoading] = useState(false)
  const [importingId, setImportingId] = useState<string | null>(null)
  const [sdkModule, setSdkModule] = useState<any>(null)

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const clientRef = useRef<any>(null)
  const cameraStreamRef = useRef<MediaStream | null>(null)
  const screenStreamRef = useRef<MediaStream | null>(null)
  const ingestEndpointRef = useRef<string | null>(null)
  const streamKeyRef = useRef<string | null>(null)

  // Check HTTPS requirement
  useEffect(() => {
    if (typeof window !== "undefined") {
      if (window.location.protocol !== "https:" && window.location.hostname !== "localhost") {
        setError("HTTPS richiesto per getUserMedia")
        setStatus("Errore: HTTPS richiesto")
      }
    }
  }, [])

  // Load IVS config (ingest endpoint + stream key)
  const loadConfig = async () => {
    if (authLoading || !user) return

    try {
      setStatus("Caricamento configurazione...")
      const token = await getFirebaseIdToken()
      if (!token) {
        setError("Token non disponibile")
        setStatus("Errore: Autenticazione richiesta")
        return
      }

      const res = await fetch("/api/admin/ivs/config", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ error: "Unknown error" }))
        if (errorData.code === "ENV_MISSING") {
          setError(`Configurazione IVS mancante: ${errorData.missing?.join(", ") || "variabili ambiente"}`)
          setStatus("Errore: Configurazione IVS mancante")
        } else {
          setError(errorData.error || `Errore ${res.status}`)
          setStatus(`Errore: ${res.status}`)
        }
        return
      }

      const data = await res.json()
      ingestEndpointRef.current = data.ingestEndpoint
      streamKeyRef.current = data.streamKey
      setConfigReady(true)
      setStatus("Config caricata. Caricamento SDK...")
    } catch (err: any) {
      console.error("[IVS] Error loading config:", err)
      setError(`Errore nel caricamento config: ${err.message}`)
      setStatus("Errore: Config non disponibile")
    }
  }

  // Load SDK after config is ready
  useEffect(() => {
    if (authLoading || !user || error) return
    if (sdkReady || sdkModule) return
    if (!configReady) return

    const loadSDK = async () => {
      try {
        setStatus("Config caricata. Carico SDK...")
        const module = await loadBroadcastSdk()
        setSdkModule(module)
        setSdkReady(true)
        setStatus("SDK pronto. Inizializzazione...")
      } catch (err: any) {
        console.error("[IVS] Failed to load SDK:", err)
        setError(`Errore nel caricamento SDK IVS: ${err.message || "Import fallito"}`)
        setStatus("Errore: SDK non disponibile")
      }
    }

    loadSDK()
  }, [configReady, sdkReady, sdkModule, error, authLoading, user])

  // Initialize IVS client when everything is ready
  useEffect(() => {
    if (error && error.includes("env IVS")) return

    const hasConfig = configReady && ingestEndpointRef.current && streamKeyRef.current
    const hasSDK = sdkReady && sdkModule
    const hasCanvas = canvasRef.current

    if (!hasConfig || !hasSDK || !hasCanvas || error) {
      // Debug logging (dev only)
      if (process.env.NODE_ENV !== "production") {
        console.log("[IVS] Init gates:", {
          configReady: String(configReady),
          hasIngestEndpoint: String(!!ingestEndpointRef.current),
          hasStreamKey: String(!!streamKeyRef.current),
          sdkReady: String(sdkReady),
          hasSDKModule: String(!!sdkModule),
          hasCanvas: String(hasCanvas),
          error: error ? String(error) : "null",
        })
      }
      return
    }

    const initClient = async () => {
      try {
        if (!sdkModule) {
          throw new Error("SDK module not loaded")
        }

        const ingestEndpoint = ingestEndpointRef.current
        if (!ingestEndpoint) {
          throw new Error("Ingest endpoint not available")
        }

        // Create client using helper
        const client = createBroadcastClient(sdkModule, ingestEndpoint)
        client.attachPreview(canvasRef.current!)

        // Get camera + mic
        const cameraStream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        })

        cameraStreamRef.current = cameraStream

        // Add video/audio with runtime compatibility
        // Try MediaStream first, fallback to MediaStreamTrack if needed
        try {
          client.addVideoInputDevice(cameraStream, "video1", { index: 0 })
        } catch (streamError: any) {
          // Fallback: try with MediaStreamTrack
          const videoTrack = cameraStream.getVideoTracks?.[0]
          if (videoTrack) {
            client.addVideoInputDevice(videoTrack, "video1", { index: 0 })
          } else {
            throw new Error("No video track available")
          }
        }

        // Add audio if available
        if (cameraStream.getAudioTracks && cameraStream.getAudioTracks().length > 0) {
          try {
            client.addAudioInputDevice(cameraStream, "audio1")
          } catch (streamError: any) {
            // Fallback: try with MediaStreamTrack
            const audioTrack = cameraStream.getAudioTracks()[0]
            if (audioTrack) {
              client.addAudioInputDevice(audioTrack, "audio1")
            }
          }
        } else {
          console.warn("[IVS] No audio tracks available, skipping audio input")
        }

        clientRef.current = client
        setStatus("Pronto (Camera attiva)")
      } catch (err: any) {
        console.error("Error initializing IVS client:", err)
        setError(err.message || "Errore nell'inizializzazione")
        setStatus("Errore: " + (err.message || "Inizializzazione fallita"))
      }
    }

    initClient()

    // Cleanup on unmount
    return () => {
      if (clientRef.current && isBroadcasting) {
        try {
          clientRef.current.stopBroadcast()
        } catch (e) {
          // Ignore cleanup errors
        }
      }
      if (cameraStreamRef.current) {
        cameraStreamRef.current.getTracks().forEach((track) => track.stop())
      }
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach((track) => track.stop())
      }
    }
  }, [configReady, sdkReady, sdkModule, error])

  // Load config when auth is ready
  useEffect(() => {
    if (authLoading || !user) return
    if (configReady) return

    loadConfig()
  }, [error, authLoading, user, configReady])

  const startBroadcast = async () => {
    if (!clientRef.current || !streamKeyRef.current) {
      setError("Client o stream key non disponibili")
      return
    }

    try {
      await clientRef.current.startBroadcast(streamKeyRef.current)
      setIsBroadcasting(true)
      setStatus("🔴 IN ONDA!")

      // Save stream metadata to Firestore
      try {
        const token = await getFirebaseIdToken()
        if (token && user) {
          const res = await fetch("/api/admin/ivs/recordings", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              action: "start",
              streamKey: streamKeyRef.current,
              startedBy: user.uid,
              startedAt: new Date().toISOString(),
            }),
          })

          // Robust response handling
          const responseText = await res.text()
          try {
            const data = responseText ? JSON.parse(responseText) : {}
            if (!res.ok) {
              console.warn("[IVS] Failed to save start metadata:", data.error || data.message)
            }
          } catch (parseError) {
            console.warn("[IVS] Failed to parse start metadata response:", parseError)
          }
        }
      } catch (metadataError: any) {
        // Don't block broadcast if metadata save fails
        console.warn("[IVS] Failed to save stream metadata:", metadataError)
      }
    } catch (err: any) {
      console.error("Error starting broadcast:", err)
      setError(err.message || "Errore nell'avvio broadcast")
      setStatus("Errore: " + (err.message || "Avvio fallito"))
    }
  }

  const stopBroadcast = async () => {
    if (!clientRef.current) return

    try {
      clientRef.current.stopBroadcast()
      setIsBroadcasting(false)
      setStatus("Offline")

      // Save stream end metadata to Firestore (idempotent)
      try {
        const token = await getFirebaseIdToken()
        if (token && user) {
          const res = await fetch("/api/admin/ivs/recordings", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              action: "stop",
              streamKey: streamKeyRef.current,
              stoppedBy: user.uid,
              stoppedAt: new Date().toISOString(),
            }),
          })

          // Robust JSON parsing
          const responseText = await res.text()
          let data: any
          try {
            data = responseText ? JSON.parse(responseText) : {}
          } catch (parseError: any) {
            console.warn("[IVS] Failed to parse stop response:", parseError)
            data = {}
          }

          if (res.ok && data.success) {
            setStatus("STOP completato")
          } else {
            console.warn("[IVS] Stop metadata save warning:", data.error || data.message || "Unknown error")
          }
        }
      } catch (metadataError: any) {
        // Don't block stop if metadata save fails
        console.warn("[IVS] Failed to save stream end metadata:", metadataError)
      }
    } catch (err: any) {
      console.error("Error stopping broadcast:", err)
      setError(err.message || "Errore nello stop broadcast")
    }
  }

  const restoreCamera = async () => {
    if (!clientRef.current || !cameraStreamRef.current) return

    try {
      // Remove current video device
      if (typeof clientRef.current.removeVideoInputDevice === "function") {
        try {
          clientRef.current.removeVideoInputDevice("video1")
        } catch (e) {
          // Ignore if remove fails
        }
      }

      // Re-add camera stream with compatibility
      const cameraStream = cameraStreamRef.current
      try {
        await clientRef.current.addVideoInputDevice(cameraStream, "video1", { index: 0 })
      } catch (streamError: any) {
        // Fallback: try with MediaStreamTrack
        const videoTrack = cameraStream.getVideoTracks?.[0]
        if (videoTrack) {
          await clientRef.current.addVideoInputDevice(videoTrack, "video1", { index: 0 })
        } else {
          throw new Error("No video track available")
        }
      }

      setIsScreenSharing(false)
      setStatus(isBroadcasting ? "🔴 IN ONDA!" : "Pronto (Camera attiva)")
    } catch (err: any) {
      console.error("Error restoring camera:", err)
      setError(err.message || "Errore nel ripristino camera")
    }
  }

  const toggleScreenShare = async () => {
    if (!clientRef.current) {
      setError("Client non disponibile")
      return
    }
    if (!cameraStreamRef.current) {
      setError("Camera stream non disponibile")
      return
    }

    try {
      if (isScreenSharing) {
        // Stop screen share, restore camera
        if (screenStreamRef.current) {
          screenStreamRef.current.getTracks().forEach((track) => track.stop())
          screenStreamRef.current = null
        }

        await restoreCamera()
      } else {
        // Start screen share
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: false,
        })

        screenStreamRef.current = screenStream

        const screenTrack = screenStream.getVideoTracks()[0]

        // Handle screen share end
        screenTrack.onended = () => {
          restoreCamera()
        }

        // Replace camera with screen share: remove camera and add screen stream
        if (typeof clientRef.current.removeVideoInputDevice === "function") {
          try {
            clientRef.current.removeVideoInputDevice("video1")
          } catch (e) {
            // Ignore if remove fails
          }
        }

        // Add screen stream with compatibility
        try {
          await clientRef.current.addVideoInputDevice(screenStream, "video1", { index: 0 })
        } catch (streamError: any) {
          // Fallback: try with MediaStreamTrack
          const videoTrack = screenStream.getVideoTracks?.[0]
          if (videoTrack) {
            await clientRef.current.addVideoInputDevice(videoTrack, "video1", { index: 0 })
          } else {
            throw new Error("No screen video track available")
          }
        }

        setIsScreenSharing(true)
        setStatus("🖥️ Condivisione schermo attiva")
      }
    } catch (err: any) {
      console.error("Error toggling screen share:", err)
      setError(err.message || "Errore nella condivisione schermo")
    }
  }

  // Disable buttons if config is missing or SDK not ready
  const isDisabled =
    !configReady ||
    !sdkReady ||
    !!error ||
    !clientRef.current ||
    !ingestEndpointRef.current ||
    !streamKeyRef.current

  // Load recordings from S3
  const loadRecordings = async () => {
    try {
      setRecordingsLoading(true)
      const token = await getFirebaseIdToken()
      if (!token) {
        console.warn("[IVS] No token available for loading recordings")
        return
      }

      const res = await fetch("/api/admin/ivs/recordings/list", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ error: "Unknown error" }))
        console.error("[IVS] Failed to load recordings:", errorData)
        return
      }

      const data = await res.json()
      setRecordings(data.recordings || [])
    } catch (err: any) {
      console.error("[IVS] Error loading recordings:", err)
    } finally {
      setRecordingsLoading(false)
    }
  }

  // Import recording
  const importRecording = async (recording: any) => {
    if (!recording.endedKey || !recording.prefix) {
      alert("Dati registrazione incompleti")
      return
    }

    const title = prompt("Inserisci un titolo per questa registrazione:", `Registrazione ${new Date(recording.endedAt || Date.now()).toLocaleString("it-IT")}`)
    if (!title) return

    try {
      setImportingId(recording.endedKey)
      const token = await getFirebaseIdToken()
      if (!token) {
        alert("Autenticazione non disponibile")
        return
      }

      const res = await fetch("/api/admin/ivs/recordings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title,
          endedKey: recording.endedKey,
          prefix: recording.prefix,
        }),
      })

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ error: "Unknown error" }))
        throw new Error(errorData.error || "Errore nell'importazione")
      }

      const data = await res.json()
      alert(`Registrazione importata con successo! ID: ${data.id}`)
      // Reload recordings to show updated list
      await loadRecordings()
    } catch (err: any) {
      console.error("[IVS] Error importing recording:", err)
      alert(`Errore nell'importazione: ${err.message}`)
    } finally {
      setImportingId(null)
    }
  }

  return (
    <AdminRequired>
      <div className="py-8">
        <DemoModeBanner />

        <Card>
          <CardHeader>
            <CardTitle>Studio Diretta</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Info: Recording */}
            <div className="rounded-md border border-blue-500/50 bg-blue-500/10 p-3 text-sm">
              <p className="font-semibold text-blue-700 dark:text-blue-400 mb-1">📹 Registrazione Diretta</p>
              <p className="text-blue-600 dark:text-blue-300">
                La registrazione della diretta viene salvata automaticamente su AWS S3 tramite IVS Recording.
                I metadati (data, durata, playback URL) vengono salvati in Firestore.
              </p>
            </div>

            {/* Status */}
            <div className="text-center">
              <p className="text-lg font-semibold">{status}</p>
              {error && (
                <div className="mt-2 space-y-2">
                  <p className="text-sm text-destructive">{error}</p>
                  {(error.includes("Token non disponibile") || error.includes("env IVS")) && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setError(null)
                        setStatus("Riprova...")
                        window.location.reload()
                      }}
                    >
                      Riprova
                    </Button>
                  )}
                </div>
              )}

              {/* Debug box (dev only) */}
              {process.env.NODE_ENV !== "production" &&
                (status.includes("attesa") || status.includes("Carico SDK") || status.includes("Inizializzazione")) &&
                !error && (
                  <div className="mt-4 p-3 bg-muted rounded-md text-left text-xs">
                    <p className="font-semibold mb-1">Debug Gates:</p>
                    <ul className="space-y-1">
                      <li>Config: {configReady ? "✅" : "❌"}</li>
                      <li>SDK: {sdkReady ? "✅" : "❌"}</li>
                      <li>SDK Module: {sdkModule ? "✅" : "❌"}</li>
                      <li>Ingest Endpoint: {ingestEndpointRef.current ? "✅" : "❌"}</li>
                      <li>Stream Key: {streamKeyRef.current ? "✅" : "❌"}</li>
                      <li>Canvas: {canvasRef.current ? "✅" : "❌"}</li>
                      <li>IVS Client: {clientRef.current ? "✅" : "❌"}</li>
                    </ul>
                  </div>
                )}
            </div>

            {/* Canvas Preview */}
            <div className="relative w-full" style={{ aspectRatio: "16/9" }}>
              <canvas
                ref={canvasRef}
                className="w-full h-full bg-black rounded-lg"
                style={{ objectFit: "contain" }}
              />
            </div>

            {/* Controls */}
            <div className="flex gap-4 justify-center flex-wrap">
              <Button
                onClick={startBroadcast}
                disabled={isDisabled || isBroadcasting}
                variant="default"
                size="lg"
                className="bg-red-600 hover:bg-red-700"
              >
                🔴 VAI LIVE
              </Button>

              <Button
                onClick={toggleScreenShare}
                disabled={isDisabled}
                variant="outline"
                size="lg"
              >
                🖥️ {isScreenSharing ? "Stop Schermo" : "Condividi Schermo"}
              </Button>

              <Button
                onClick={stopBroadcast}
                disabled={!isBroadcasting}
                variant="destructive"
                size="lg"
              >
                ⬛ STOP
              </Button>
            </div>

            {/* Recordings Section */}
            <div className="mt-8 pt-8 border-t">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Registrazioni da S3</h3>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={loadRecordings}
                  disabled={recordingsLoading}
                >
                  {recordingsLoading ? "Caricamento..." : "🔄 Aggiorna elenco"}
                </Button>
              </div>

              {recordings.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <p>Nessuna registrazione trovata in S3.</p>
                  <p className="text-sm mt-2">Clicca "Aggiorna elenco" per cercare nuove registrazioni.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {recordings.map((recording, idx) => (
                    <div
                      key={recording.endedKey || idx}
                      className="flex items-center justify-between p-3 border rounded-md hover:bg-muted transition-colors"
                    >
                      <div className="flex-1">
                        <p className="font-medium">
                          {recording.endedAt
                            ? new Date(recording.endedAt).toLocaleString("it-IT")
                            : "Data sconosciuta"}
                        </p>
                        <div className="flex gap-4 text-sm text-muted-foreground mt-1">
                          {recording.channelId && <span>Channel: {recording.channelId}</span>}
                          {recording.duration && <span>Durata: {Math.round(recording.duration / 60)}m</span>}
                          <span className={recording.hasMediaHls ? "text-green-600" : "text-yellow-600"}>
                            {recording.hasMediaHls ? "✅ HLS disponibile" : "⚠️ HLS non trovato"}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1 font-mono">{recording.prefix}</p>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => importRecording(recording)}
                        disabled={importingId === recording.endedKey}
                      >
                        {importingId === recording.endedKey ? "Importazione..." : "📥 Importa"}
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminRequired>
  )
}
